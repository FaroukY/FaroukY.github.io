"""
Neuroevolution for LunarLander-v3
==================================
Train a neural network policy using a Genetic Algorithm.

The GA operators (tournament selection, mutation, crossover) are the same
continuous-vector operators from Lecture 16 — applied to the 836 weights
of a small neural network.

Usage:
    pip install numpy torch gymnasium[box2d]
    python hw7_p5_lander.py

After training, submit the file 'lunar_policy.pt' to Gradescope.
"""

import copy
import numpy as np
import torch
import torch.nn as nn


# ── Fixed architecture (DO NOT MODIFY) ──────────────────────────────────────
class LunarPolicy(nn.Module):
    """8 → 64 (ReLU) → 4  — total 836 parameters."""

    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(8, 64),
            nn.ReLU(),
            nn.Linear(64, 4),
        )

    def forward(self, x):
        return self.net(x)

    def select_action(self, state):
        """Given a numpy state vector, return the action (int)."""
        with torch.no_grad():
            t = torch.FloatTensor(state).unsqueeze(0)
            return self.net(t).argmax(dim=1).item()


# ── Provided utility ────────────────────────────────────────────────────────
def evaluate_policy(model, env, n_episodes=3, max_steps=1000):
    """Return average total reward over *n_episodes*."""
    total = 0.0
    for _ in range(n_episodes):
        state, _ = env.reset()
        ep_reward = 0.0
        for _ in range(max_steps):
            action = model.select_action(state)
            state, reward, terminated, truncated, _ = env.step(action)
            ep_reward += reward
            if terminated or truncated:
                break
        total += ep_reward
    return total / n_episodes


# ── TODO: Implement these three functions ────────────────────────────────────

def tournament_select(population, fitnesses, k=5):
    """
    Select the best individual from *k* randomly chosen members.

    Algorithm
    ---------
    1. Sample k indices uniformly at random (without replacement).
    2. Among those k, pick the one with the highest fitness.
    3. Return a **deep copy** of that individual.

    Parameters
    ----------
    population : list[LunarPolicy]
        Current population of neural networks.
    fitnesses  : list[float]
        Fitness (average episode reward) for each member — same length as
        *population*.
    k : int
        Tournament size (default 5).

    Returns
    -------
    LunarPolicy
        A deep copy of the tournament winner.
    """
    raise NotImplementedError


def mutate(model, sigma=0.1):
    """
    Add Gaussian noise N(0, sigma²) to every weight and bias **in-place**.

    For each parameter tensor *p* in the model:
        p ← p + ε,   ε ~ N(0, σ²)   (element-wise)

    Parameters
    ----------
    model : LunarPolicy
        The model to mutate (modified in-place).
    sigma : float
        Standard deviation of the Gaussian noise.

    Returns
    -------
    LunarPolicy
        The same model object (now mutated).

    Hint
    ----
    Loop over model.parameters() and use  p.data.add_(torch.randn_like(p) * sigma).
    """
    raise NotImplementedError


def crossover(parent1, parent2):
    """
    Blend crossover: child_w = β * p1_w + (1 − β) * p2_w.

    For each parameter tensor, sample β ~ Uniform(0, 1) independently,
    then set the child's parameter to the weighted combination.

    Parameters
    ----------
    parent1 : LunarPolicy
    parent2 : LunarPolicy

    Returns
    -------
    LunarPolicy
        A new child model with blended weights.

    Hint
    ----
    Use zip(child.parameters(), parent1.parameters(), parent2.parameters())
    to iterate over corresponding tensors.  Sample β with torch.rand(1).item().
    """
    raise NotImplementedError


# ── Training loop (modify hyperparameters as needed) ─────────────────────────
if __name__ == "__main__":
    from lunar_lander_env import LunarLanderEnv

    env = LunarLanderEnv()

    # Hyperparameters — feel free to adjust
    POP_SIZE = 50
    N_GENERATIONS = 100
    SIGMA = 0.1
    TOURNAMENT_K = 5
    ELITISM = 2
    EVAL_EPISODES = 3

    # Initialize population
    population = [LunarPolicy() for _ in range(POP_SIZE)]

    best_ever_fitness = -float("inf")
    best_ever_model = None

    for gen in range(N_GENERATIONS):
        # Evaluate fitness of every individual
        fitnesses = [evaluate_policy(p, env, EVAL_EPISODES) for p in population]

        # Track best in this generation and all-time best
        gen_best_idx = int(np.argmax(fitnesses))
        gen_best_fit = fitnesses[gen_best_idx]
        if gen_best_fit > best_ever_fitness:
            best_ever_fitness = gen_best_fit
            best_ever_model = copy.deepcopy(population[gen_best_idx])

        print(
            f"Gen {gen:3d} | best {gen_best_fit:8.1f} | "
            f"avg {np.mean(fitnesses):8.1f} | "
            f"all-time best {best_ever_fitness:8.1f}"
        )

        # ── Build next generation ──
        # Keep top ELITISM individuals unchanged
        ranked = sorted(range(POP_SIZE), key=lambda i: fitnesses[i], reverse=True)
        new_pop = [copy.deepcopy(population[ranked[i]]) for i in range(ELITISM)]

        # Fill remaining slots via selection + crossover + mutation
        while len(new_pop) < POP_SIZE:
            p1 = tournament_select(population, fitnesses, TOURNAMENT_K)
            p2 = tournament_select(population, fitnesses, TOURNAMENT_K)
            child = crossover(p1, p2)
            mutate(child, SIGMA)
            new_pop.append(child)

        population = new_pop

    # Save best model
    torch.save(best_ever_model.state_dict(), "lunar_policy.pt")
    print(f"\nSaved lunar_policy.pt  (best fitness: {best_ever_fitness:.1f})")
    env.close()
