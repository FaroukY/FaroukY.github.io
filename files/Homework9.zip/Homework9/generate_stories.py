"""
Generate stories from a trained transformer model.

Usage:
    python generate_stories.py --checkpoint model_checkpoint.pt \
        --vocab vocab.json --merges merges.txt
"""

import argparse
import torch
from hw9_p2_model_solution import TransformerLM, generate
from hw9_p1_bpe_solution import Tokenizer

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="model_checkpoint.pt")
    parser.add_argument("--vocab", type=str, default="vocab.json")
    parser.add_argument("--merges", type=str, default="merges.txt")
    parser.add_argument("--prompt", type=str, default="Once upon a time")
    parser.add_argument("--max_tokens", type=int, default=200)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--top_p", type=float, default=0.9)
    parser.add_argument("--num_samples", type=int, default=5)
    parser.add_argument("--device", type=str, default="cuda")
    args = parser.parse_args()

    # Load tokenizer
    print("Loading tokenizer...")
    tokenizer = Tokenizer.from_files(args.vocab, args.merges, ["<|endoftext|>"])

    # Load model
    print("Loading model...")
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model = TransformerLM(
        vocab_size=32256,
        d_model=1024,
        n_layers=24,
        n_heads=16,
        d_ff=2730,
        max_seq_len=512,
    ).to(device)
    state_dict = torch.load(args.checkpoint, map_location=device, weights_only=True)
    model.load_state_dict(state_dict)
    model.eval()
    print(f"Model loaded on {device}")

    # Generate
    prompts = [
        "Once upon a time",
        "There was a little girl named Lily",
        "One day, a big bear",
        "The sun was shining and",
        "Tom and his mom went to the",
    ]

    temperatures = [0.3, 0.8, 1.0]

    with open("generated_samples.txt", "w") as f:
        for temp in temperatures:
            f.write(f"\n{'='*60}\n")
            f.write(f"Temperature = {temp}\n")
            f.write(f"{'='*60}\n\n")
            print(f"\n--- Temperature {temp} ---")

            for prompt in prompts:
                prompt_ids = tokenizer.encode(prompt)
                output_ids = generate(
                    model, prompt_ids,
                    max_new_tokens=args.max_tokens,
                    temperature=temp,
                    top_p=args.top_p,
                )
                text = tokenizer.decode(output_ids)

                # Stop at endoftext if generated
                if "<|endoftext|>" in text:
                    text = text[:text.index("<|endoftext|>")]

                print(f"\nPrompt: {prompt}")
                print(f"Output: {text}\n")

                f.write(f"Prompt: {prompt}\n")
                f.write(f"Output: {text}\n\n")

    print("\nSaved to generated_samples.txt")

if __name__ == "__main__":
    main()
