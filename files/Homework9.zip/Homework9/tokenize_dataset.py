"""
Tokenize a text dataset using a trained BPE tokenizer.
Saves as a numpy array of uint16 token IDs.

Usage:
    python tokenize_dataset.py \
        --input TinyStoriesV2-GPT4-train.txt \
        --vocab vocab.json --merges merges.txt \
        --output tinystories_tokens.npy
"""

import argparse
import json
import time
import numpy as np
import regex

GPT2_PATTERN = r"""'(?:[sdmt]|ll|ve|re)| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""


def load_tokenizer(vocab_path, merges_path, special_tokens):
    """Load vocab and build a fast encoding lookup."""
    with open(vocab_path) as f:
        vocab = {int(k): bytes(v) for k, v in json.load(f).items()}

    merges = []
    with open(merges_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            sep = line.index("] [")
            a = bytes(json.loads(line[:sep + 1]))
            b = bytes(json.loads(line[sep + 2:]))
            merges.append((a, b))

    # Build bytes -> id lookup
    bytes_to_id = {v: k for k, v in vocab.items()}

    # Build merge lookup: (a_id, b_id) -> merged_id for fast encoding
    byte_offset = len(special_tokens)
    merge_lookup = {}
    for i, (a_bytes, b_bytes) in enumerate(merges):
        a_id = bytes_to_id[a_bytes]
        b_id = bytes_to_id[b_bytes]
        merged_id = byte_offset + 256 + i
        merge_lookup[(a_id, b_id)] = merged_id

    return vocab, bytes_to_id, merge_lookup, byte_offset, special_tokens


def encode_pretoken(byte_tuple, byte_offset, merge_lookup):
    """Encode a single pre-token using the merge lookup (BFS-style, not linear scan)."""
    # Start with byte-level token IDs
    ids = [b + byte_offset for b in byte_tuple]

    # Repeatedly find and apply the highest-priority merge
    # (the one with the lowest merge index = earliest in merge list)
    changed = True
    while changed and len(ids) > 1:
        changed = False
        # Find the pair with the lowest merged_id (= highest priority merge)
        best_i = -1
        best_merged_id = float('inf')
        for i in range(len(ids) - 1):
            pair = (ids[i], ids[i + 1])
            if pair in merge_lookup:
                mid = merge_lookup[pair]
                if mid < best_merged_id:
                    best_merged_id = mid
                    best_i = i
        if best_i >= 0:
            ids[best_i:best_i + 2] = [best_merged_id]
            changed = True

    return ids


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, required=True)
    parser.add_argument("--vocab", type=str, required=True)
    parser.add_argument("--merges", type=str, required=True)
    parser.add_argument("--output", type=str, required=True)
    parser.add_argument("--special_tokens", type=str, nargs="*",
                        default=["<|endoftext|>"])
    args = parser.parse_args()

    print(f"Loading tokenizer from {args.vocab} and {args.merges}...")
    vocab, bytes_to_id, merge_lookup, byte_offset, special_tokens = load_tokenizer(
        args.vocab, args.merges, args.special_tokens
    )
    print(f"Vocabulary size: {len(vocab)}, Merges: {len(merge_lookup)}")

    # Build special token regex
    special_escaped = [regex.escape(t) for t in sorted(special_tokens, key=len, reverse=True)]
    special_pattern = "|".join(special_escaped) if special_escaped else None

    print(f"Tokenizing {args.input}...")
    t0 = time.time()

    token_ids = []
    lines_processed = 0

    with open(args.input, "r", encoding="utf-8") as f:
        for line in f:
            # Split on special tokens
            if special_pattern:
                segments = []
                last_end = 0
                for m in regex.finditer(special_pattern, line):
                    if m.start() > last_end:
                        segments.append((line[last_end:m.start()], False))
                    segments.append((m.group(), True))
                    last_end = m.end()
                if last_end < len(line):
                    segments.append((line[last_end:], False))
            else:
                segments = [(line, False)]

            for segment, is_special in segments:
                if is_special:
                    token_ids.append(bytes_to_id[segment.encode("utf-8")])
                    continue

                # Pre-tokenize with GPT-2 regex
                for match in regex.finditer(GPT2_PATTERN, segment):
                    byte_tuple = tuple(match.group().encode("utf-8"))
                    ids = encode_pretoken(byte_tuple, byte_offset, merge_lookup)
                    token_ids.extend(ids)

            lines_processed += 1
            if lines_processed % 100000 == 0:
                elapsed = time.time() - t0
                print(f"  {lines_processed:,} lines, {len(token_ids):,} tokens ({elapsed:.1f}s)")

    elapsed = time.time() - t0
    print(f"Done: {len(token_ids):,} tokens in {elapsed:.1f}s")

    # Save
    tokens_array = np.array(token_ids, dtype=np.uint16)
    np.save(args.output, tokens_array)
    print(f"Saved to {args.output} ({tokens_array.nbytes / 1024 / 1024:.1f} MB)")

    # Stats
    with open(args.input, "rb") as f:
        f.seek(0, 2)
        file_bytes = f.tell()
    print(f"Compression: {file_bytes / len(token_ids):.2f} bytes/token")


if __name__ == "__main__":
    main()
