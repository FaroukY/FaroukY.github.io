"""
CS498 Homework 9 - Problem 1: Train a BPE Tokenizer

You will implement ONE function: train_bpe().
Everything else (Tokenizer class, pre-tokenization, serialization) is provided.

Background:
    BPE starts with a vocabulary of 256 byte tokens (every possible byte value 0-255).
    It then iteratively finds the most frequent adjacent pair of tokens in the corpus,
    merges them into a new token, and adds it to the vocabulary. This continues until
    the vocabulary reaches the desired size.

    Example: if the most frequent pair is (b'h', b'e'), we merge them into b'he'.
    Now every occurrence of h followed by e in the corpus becomes the single token 'he'.

What is "bytes"?
    Text is stored as bytes (integers 0-255). ASCII characters are one byte each:
        >>> list("hello".encode("utf-8"))
        [104, 101, 108, 108, 111]          # h=104, e=101, l=108, o=111

    Non-ASCII characters use multiple bytes:
        >>> list("cafe".encode("utf-8"))    # plain ASCII, 4 bytes
        [99, 97, 102, 101]
        >>> list("cafe\\u0301".encode("utf-8"))  # with accent, 6 bytes
        [99, 97, 102, 101, 204, 129]

    BPE works on these raw byte values. The initial vocabulary is simply
    {0: b'\\x00', 1: b'\\x01', ..., 255: b'\\xff'} -- every possible byte.

What is the frequency table?
    Before merging, we pre-tokenize the corpus into "words" (using a regex),
    and count how often each word appears. Each word is stored as a tuple of
    byte values. For example, if "the" appears 1000 times in the corpus:

        freq_table = {
            (116, 104, 101): 1000,   # "the" as bytes
            (99, 97, 116): 500,      # "cat" as bytes
            ...
        }

    When counting pairs, each pair's count is weighted by the word's frequency.
    So the pair (104, 101) -- i.e., (h, e) -- gets count 1000 from "the" alone.

Usage:
    python hw9_p1_bpe.py --input /projects/bgvu/shared_data/data/owt_train.txt
"""

import argparse
import json
import os
import time
from collections import defaultdict
from multiprocessing import Pool, cpu_count

import regex


# ===========================================================================
# GPT-2 pre-tokenization pattern (requires `regex` library, not `re`)
#
# This splits text into "words" like:
#   >>> regex.findall(GPT2_PATTERN, "Hello world! It's a test.")
#   ['Hello', ' world', '!', " It", "'s", ' a', ' test', '.']
#
# Notice: spaces attach to the FOLLOWING word (" world", not "world ").
# Contractions are split off ("'s" is separate from "It").
# ===========================================================================
GPT2_PATTERN = r"""'(?:[sdmt]|ll|ve|re)| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""


# ===========================================================================
# Pre-tokenization (PROVIDED -- you don't need to modify this)
#
# Splits the corpus into "words", converts each to bytes, and counts
# how often each word appears. The result is a frequency table:
#     {(104, 101, 108, 108, 111): 500, ...}  # "hello" appears 500 times
#
# This uses multiprocessing to parallelize across CPU cores.
# ===========================================================================

def _split_on_special_tokens(text, special_tokens):
    """Split text on special token boundaries. Returns [(segment, is_special), ...]"""
    if not special_tokens:
        return [(text, False)]
    escaped = [regex.escape(t) for t in sorted(special_tokens, key=len, reverse=True)]
    pattern = "|".join(escaped)
    result = []
    last_end = 0
    for m in regex.finditer(pattern, text):
        if m.start() > last_end:
            result.append((text[last_end:m.start()], False))
        result.append((m.group(), True))
        last_end = m.end()
    if last_end < len(text):
        result.append((text[last_end:], False))
    return result


def _pretokenize_chunk(args):
    """Pre-tokenize one chunk of text. Called by multiprocessing."""
    text_chunk, special_tokens = args
    freq = defaultdict(int)
    for segment, is_special in _split_on_special_tokens(text_chunk, special_tokens):
        if is_special:
            continue  # special tokens are boundaries, not merged
        for match in regex.finditer(GPT2_PATTERN, segment):
            word_bytes = tuple(match.group().encode("utf-8"))
            freq[word_bytes] += 1
    return dict(freq)


def pretokenize(input_path, special_tokens, num_workers=None):
    """
    Pre-tokenize a text file in parallel.

    Returns a frequency table: dict mapping tuple-of-bytes to count.
    Example: {(116, 104, 101): 1000, ...}  means "the" appeared 1000 times.
    """
    if num_workers is None:
        num_workers = cpu_count()

    with open(input_path, "r", encoding="utf-8") as f:
        text = f.read()

    # Split into roughly equal chunks on newline boundaries
    chunk_size = max(1, len(text) // num_workers)
    chunks = []
    start = 0
    for _ in range(num_workers - 1):
        end = text.find("\n", start + chunk_size)
        end = len(text) if end == -1 else end + 1
        chunks.append(text[start:end])
        start = end
        if start >= len(text):
            break
    if start < len(text):
        chunks.append(text[start:])

    with Pool(num_workers) as pool:
        results = pool.map(_pretokenize_chunk, [(c, special_tokens) for c in chunks])

    # Merge frequency tables from all workers
    merged = defaultdict(int)
    for freq in results:
        for k, v in freq.items():
            merged[k] += v
    return dict(merged)


# ===========================================================================
# TODO: Implement this function
# ===========================================================================

def train_bpe(
    input_path: str,
    vocab_size: int,
    special_tokens: list[str],
) -> tuple[dict[int, bytes], list[tuple[bytes, bytes]]]:
    """
    Train a BPE tokenizer on the given text file.

    Parameters
    ----------
    input_path : str
        Path to training text file.
    vocab_size : int
        Desired vocabulary size. The number of merges to perform is:
        vocab_size - 256 (byte tokens) - len(special_tokens)
    special_tokens : list[str]
        Special tokens like ["<|endoftext|>"]. These get IDs 0, 1, 2, ...
        The 256 byte tokens get IDs len(special_tokens) through len(special_tokens)+255.
        Each merge adds one more token after that.

    Returns
    -------
    vocab : dict[int, bytes]
        Maps token ID (int) to token content (bytes).
        Example: {0: b'<|endoftext|>', 1: b'\\x00', ..., 257: b'th', ...}

    merges : list[tuple[bytes, bytes]]
        Ordered list of merges performed.
        Example: [(b't', b'h'), (b'th', b'e'), ...]
        meaning: first merge t+h -> th, then merge th+e -> the, etc.

    Algorithm
    ---------
    1. Call pretokenize() to get the frequency table. (PROVIDED)

    2. Build initial pair counts: for each word in the frequency table,
       count every adjacent pair, weighted by the word's frequency.

       Example: word (116, 104, 101) with freq 1000 contributes:
           pair (116, 104) += 1000   # t, h
           pair (104, 101) += 1000   # h, e

    3. Find the most frequent pair. Break ties by choosing the
       lexicographically larger pair.

    4. Merge: replace every occurrence of that pair in every word
       with a new token ID. Update the pair counts (only the pairs
       adjacent to the merge site change).

    5. Repeat steps 3-4 until you've done enough merges.

    6. Build the vocabulary dict and return it.

    Efficiency hint: use a max-heap (heapq with negated counts) to find
    the most frequent pair in O(log n) instead of scanning all pairs.
    After merging, the heap may contain stale entries -- check that the
    count is still valid when popping.
    """
    num_merges = vocab_size - 256 - len(special_tokens)

    # Step 1: pre-tokenize (provided)
    print("Pre-tokenizing corpus...")
    t0 = time.time()
    freq_table = pretokenize(input_path, special_tokens)
    print(f"  {len(freq_table):,} unique words in {time.time() - t0:.1f}s")

    # TODO: implement steps 2-6
    raise NotImplementedError


# ===========================================================================
# Tokenizer class (PROVIDED -- uses your train_bpe output)
# ===========================================================================

class Tokenizer:
    """
    BPE tokenizer. Given a vocab and merges (from train_bpe), encodes text
    to token IDs and decodes back.

    Example usage:
        vocab, merges = train_bpe("corpus.txt", 1000, ["<|endoftext|>"])
        tok = Tokenizer(vocab, merges, ["<|endoftext|>"])
        ids = tok.encode("Hello world!")       # [372, 8421, 0]
        text = tok.decode(ids)                 # "Hello world!"
        assert text == "Hello world!"
    """

    def __init__(self, vocab, merges, special_tokens=None):
        self.vocab = vocab
        self.merges = merges
        self.special_tokens = special_tokens or []
        self.bytes_to_id = {v: k for k, v in vocab.items()}
        self.byte_offset = len(self.special_tokens)

        # Pre-compute merge triples: (a_id, b_id, merged_id)
        self._merge_triples = []
        for i, (a_bytes, b_bytes) in enumerate(merges):
            self._merge_triples.append((
                self.bytes_to_id[a_bytes],
                self.bytes_to_id[b_bytes],
                self.byte_offset + 256 + i,
            ))

    def encode(self, text):
        """Encode text to a list of token IDs."""
        ids = []
        for segment, is_special in _split_on_special_tokens(text, self.special_tokens):
            if is_special:
                ids.append(self.bytes_to_id[segment.encode("utf-8")])
                continue
            for match in regex.finditer(GPT2_PATTERN, segment):
                token_ids = [b + self.byte_offset for b in match.group().encode("utf-8")]
                # Apply merges in order
                for a_id, b_id, merged_id in self._merge_triples:
                    new = []
                    i = 0
                    while i < len(token_ids):
                        if i < len(token_ids) - 1 and token_ids[i] == a_id and token_ids[i + 1] == b_id:
                            new.append(merged_id)
                            i += 2
                        else:
                            new.append(token_ids[i])
                            i += 1
                    token_ids = new
                ids.extend(token_ids)
        return ids

    def decode(self, ids):
        """Decode token IDs back to text."""
        return b"".join(self.vocab[i] for i in ids).decode("utf-8", errors="replace")

    def encode_iterable(self, iterable):
        """Encode an iterable of strings, yielding token IDs lazily."""
        for line in iterable:
            yield from self.encode(line)

    def save(self, vocab_path, merges_path):
        """Save vocab and merges to disk."""
        with open(vocab_path, "w") as f:
            json.dump({str(k): list(v) for k, v in self.vocab.items()}, f)
        with open(merges_path, "w") as f:
            for a, b in self.merges:
                f.write(f"{list(a)} {list(b)}\n")

    @classmethod
    def from_files(cls, vocab_path, merges_path, special_tokens=None):
        """Load from saved files."""
        with open(vocab_path) as f:
            vocab = {int(k): bytes(v) for k, v in json.load(f).items()}
        merges = []
        with open(merges_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                # Format: [a1, a2, ...] [b1, b2, ...]
                # Find the "] [" separator between the two lists
                sep = line.index("] [")
                a_str = line[:sep + 1]
                b_str = line[sep + 2:]
                merges.append((bytes(json.loads(a_str)), bytes(json.loads(b_str))))
        return cls(vocab, merges, special_tokens)


# ===========================================================================
# Main: train, save, and test
# ===========================================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train BPE tokenizer")
    parser.add_argument("--input", type=str, required=True,
                        help="Path to training text file")
    parser.add_argument("--vocab_size", type=int, default=32256,
                        help="Target vocab size (default: 32256 = 1 special + 256 bytes + 32000 merges)")
    parser.add_argument("--special_tokens", type=str, nargs="*",
                        default=["<|endoftext|>"])
    parser.add_argument("--output_dir", type=str, default=".")
    args = parser.parse_args()

    # Train
    vocab, merges = train_bpe(args.input, args.vocab_size, args.special_tokens)

    # Stats
    longest = max(vocab.values(), key=len)
    print(f"\nVocab size: {len(vocab)}")
    print(f"Merges: {len(merges)}")
    print(f"Longest token: {longest.decode('utf-8', errors='replace')!r} ({len(longest)} bytes)")

    # Save
    tokenizer = Tokenizer(vocab, merges, args.special_tokens)
    vocab_path = os.path.join(args.output_dir, "vocab.json")
    merges_path = os.path.join(args.output_dir, "merges.txt")
    tokenizer.save(vocab_path, merges_path)
    print(f"Saved to {vocab_path} and {merges_path}")

    # Quick roundtrip test
    test = "Hello, world! <|endoftext|> The cat sat on the mat."
    encoded = tokenizer.encode(test)
    decoded = tokenizer.decode(encoded)
    print(f"\nTest: {test!r}")
    print(f"  -> {len(encoded)} tokens: {encoded[:10]}...")
    print(f"  -> decoded: {decoded!r}")
    assert decoded == test, "Roundtrip FAILED!"
    print("  Roundtrip OK!")
