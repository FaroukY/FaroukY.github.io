"""
CS498 Homework 9 - Problem 1: Train a BPE Tokenizer -- SOLUTION

Only train_bpe() is implemented. Everything else is the same as the skeleton.
"""

import argparse
import heapq
import json
import os
import time
from collections import defaultdict
from multiprocessing import Pool, cpu_count

import regex

GPT2_PATTERN = r"""'(?:[sdmt]|ll|ve|re)| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""


# Pre-tokenization (same as skeleton)

def _split_on_special_tokens(text, special_tokens):
    if not special_tokens:
        return [(text, False)]
    escaped = [regex.escape(t) for t in sorted(special_tokens, key=len, reverse=True)]
    pattern = "|".join(escaped)
    result = []
    last_end = 0
    for m in regex.finditer(pattern, text):
        if m.start() > last_end:
            result.append((text[last_end:m.start()], False))
        result.append((m.group(), True))
        last_end = m.end()
    if last_end < len(text):
        result.append((text[last_end:], False))
    return result


def _pretokenize_chunk(args):
    text_chunk, special_tokens = args
    freq = defaultdict(int)
    for segment, is_special in _split_on_special_tokens(text_chunk, special_tokens):
        if is_special:
            continue
        for match in regex.finditer(GPT2_PATTERN, segment):
            freq[tuple(match.group().encode("utf-8"))] += 1
    return dict(freq)


def pretokenize(input_path, special_tokens, num_workers=None):
    if num_workers is None:
        num_workers = cpu_count()
    with open(input_path, "r", encoding="utf-8") as f:
        text = f.read()
    chunk_size = max(1, len(text) // num_workers)
    chunks = []
    start = 0
    for _ in range(num_workers - 1):
        end = text.find("\n", start + chunk_size)
        end = len(text) if end == -1 else end + 1
        chunks.append(text[start:end])
        start = end
        if start >= len(text):
            break
    if start < len(text):
        chunks.append(text[start:])
    with Pool(num_workers) as pool:
        results = pool.map(_pretokenize_chunk, [(c, special_tokens) for c in chunks])
    merged = defaultdict(int)
    for freq in results:
        for k, v in freq.items():
            merged[k] += v
    return dict(merged)


# ===========================================================================
# SOLUTION: train_bpe
# ===========================================================================

def train_bpe(input_path, vocab_size, special_tokens):
    num_merges = vocab_size - 256 - len(special_tokens)
    assert num_merges >= 0

    # Step 1: pre-tokenize
    print("Pre-tokenizing...")
    t0 = time.time()
    freq_table = pretokenize(input_path, special_tokens)
    print(f"  {len(freq_table):,} unique words in {time.time() - t0:.1f}s")

    byte_offset = len(special_tokens)

    # Convert to mutable words: [[token_id, token_id, ...], frequency]
    # Token IDs for raw bytes are byte_value + byte_offset
    words = []
    for byte_tuple, count in freq_table.items():
        words.append([[b + byte_offset for b in byte_tuple], count])

    # Step 2: build initial pair counts
    pair_counts = defaultdict(int)
    pair_to_words = defaultdict(set)  # which word indices contain each pair

    for wi, (tokens, freq) in enumerate(words):
        for i in range(len(tokens) - 1):
            pair = (tokens[i], tokens[i + 1])
            pair_counts[pair] += freq
            pair_to_words[pair].add(wi)

    # Max-heap: (-count, (-a, -b), (a, b))
    # Negating the pair gives lexicographic tiebreak (larger pair wins)
    heap = []
    for pair, count in pair_counts.items():
        heapq.heappush(heap, (-count, (-pair[0], -pair[1]), pair))

    # Track token bytes for building vocab
    id_to_bytes = {b + byte_offset: bytes([b]) for b in range(256)}

    # Steps 3-4: merge loop
    merges = []
    print("Merging...")
    t0 = time.time()

    for merge_i in range(num_merges):
        # Pop the most frequent pair (skip stale entries)
        while heap:
            neg_count, _, pair = heapq.heappop(heap)
            actual = pair_counts.get(pair, 0)
            if actual == -neg_count and actual > 0:
                break
        else:
            break

        a_id, b_id = pair
        new_id = byte_offset + 256 + merge_i
        id_to_bytes[new_id] = id_to_bytes[a_id] + id_to_bytes[b_id]
        merges.append((id_to_bytes[a_id], id_to_bytes[b_id]))

        # Update all words containing this pair
        affected = list(pair_to_words.pop(pair, []))
        del pair_counts[pair]

        for wi in affected:
            tokens, freq = words[wi]
            i = 0
            while i < len(tokens) - 1:
                if tokens[i] == a_id and tokens[i + 1] == b_id:
                    # Decrement old neighbor pairs
                    if i > 0:
                        lp = (tokens[i - 1], a_id)
                        pair_counts[lp] -= freq
                        pair_to_words[lp].discard(wi)
                    if i + 2 < len(tokens):
                        rp = (b_id, tokens[i + 2])
                        pair_counts[rp] -= freq
                        pair_to_words[rp].discard(wi)

                    # Replace pair with new token
                    tokens[i:i + 2] = [new_id]

                    # Increment new neighbor pairs
                    if i > 0:
                        nl = (tokens[i - 1], new_id)
                        pair_counts[nl] += freq
                        pair_to_words[nl].add(wi)
                        heapq.heappush(heap, (-pair_counts[nl], (-nl[0], -nl[1]), nl))
                    if i + 1 < len(tokens):
                        nr = (new_id, tokens[i + 1])
                        pair_counts[nr] += freq
                        pair_to_words[nr].add(wi)
                        heapq.heappush(heap, (-pair_counts[nr], (-nr[0], -nr[1]), nr))
                else:
                    i += 1

        if (merge_i + 1) % 1000 == 0:
            print(f"  {merge_i + 1}/{num_merges} ({time.time() - t0:.1f}s)")

    print(f"  {len(merges)} merges in {time.time() - t0:.1f}s")

    # Step 5: build vocabulary
    vocab = {}
    for i, st in enumerate(special_tokens):
        vocab[i] = st.encode("utf-8")
    for b in range(256):
        vocab[b + byte_offset] = bytes([b])
    for i, (a, b) in enumerate(merges):
        vocab[byte_offset + 256 + i] = a + b

    return vocab, merges


# ===========================================================================
# Tokenizer (same as skeleton -- provided, not implemented by students)
# ===========================================================================

class Tokenizer:
    def __init__(self, vocab, merges, special_tokens=None):
        self.vocab = vocab
        self.merges = merges
        self.special_tokens = special_tokens or []
        self.bytes_to_id = {v: k for k, v in vocab.items()}
        self.byte_offset = len(self.special_tokens)
        self._merge_triples = []
        for i, (a_bytes, b_bytes) in enumerate(merges):
            self._merge_triples.append((
                self.bytes_to_id[a_bytes],
                self.bytes_to_id[b_bytes],
                self.byte_offset + 256 + i,
            ))

    def encode(self, text):
        ids = []
        for segment, is_special in _split_on_special_tokens(text, self.special_tokens):
            if is_special:
                ids.append(self.bytes_to_id[segment.encode("utf-8")])
                continue
            for match in regex.finditer(GPT2_PATTERN, segment):
                token_ids = [b + self.byte_offset for b in match.group().encode("utf-8")]
                for a_id, b_id, merged_id in self._merge_triples:
                    new = []
                    i = 0
                    while i < len(token_ids):
                        if i < len(token_ids) - 1 and token_ids[i] == a_id and token_ids[i + 1] == b_id:
                            new.append(merged_id)
                            i += 2
                        else:
                            new.append(token_ids[i])
                            i += 1
                    token_ids = new
                ids.extend(token_ids)
        return ids

    def decode(self, ids):
        return b"".join(self.vocab[i] for i in ids).decode("utf-8", errors="replace")

    def encode_iterable(self, iterable):
        for line in iterable:
            yield from self.encode(line)

    def save(self, vocab_path, merges_path):
        with open(vocab_path, "w") as f:
            json.dump({str(k): list(v) for k, v in self.vocab.items()}, f)
        with open(merges_path, "w") as f:
            for a, b in self.merges:
                f.write(f"{list(a)} {list(b)}\n")

    @classmethod
    def from_files(cls, vocab_path, merges_path, special_tokens=None):
        with open(vocab_path) as f:
            vocab = {int(k): bytes(v) for k, v in json.load(f).items()}
        merges = []
        with open(merges_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                sep = line.index("] [")
                a_str = line[:sep + 1]
                b_str = line[sep + 2:]
                merges.append((bytes(json.loads(a_str)), bytes(json.loads(b_str))))
        return cls(vocab, merges, special_tokens)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, required=True)
    parser.add_argument("--vocab_size", type=int, default=32256)
    parser.add_argument("--special_tokens", type=str, nargs="*", default=["<|endoftext|>"])
    parser.add_argument("--output_dir", type=str, default=".")
    args = parser.parse_args()

    vocab, merges = train_bpe(args.input, args.vocab_size, args.special_tokens)

    longest = max(vocab.values(), key=len)
    print(f"\nVocab: {len(vocab)}, Longest: {longest.decode('utf-8', errors='replace')!r} ({len(longest)}B)")

    tokenizer = Tokenizer(vocab, merges, args.special_tokens)
    tokenizer.save(
        os.path.join(args.output_dir, "vocab.json"),
        os.path.join(args.output_dir, "merges.txt"),
    )

    test = "Hello, world! <|endoftext|> The cat sat on the mat."
    assert tokenizer.decode(tokenizer.encode(test)) == test
    print("Roundtrip OK!")
