"""
Transformer Language Model for OpenWebText
============================================
Implement a decoder-only transformer with RoPE, RMSNorm, SwiGLU, and
multi-head causal attention. Train on OpenWebText to generate English text.

Reference architecture:
    d_model=1024, n_layers=24, n_heads=16, d_ff=2730,
    context_length=512, vocab_size=32256

Reference papers:
    - Attention Is All You Need (Vaswani et al., 2017)
    - RoFormer: Enhanced Transformer with Rotary Position Embedding (Su et al., 2021)
    - GLU Variants Improve Transformer (Shazeer, 2020)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# =========================================================================
# Rotary Positional Encoding (PROVIDED -- do not modify)
# =========================================================================

def precompute_rope_frequencies(dim: int, max_seq_len: int, theta: float = 10000.0):
    """
    Precompute the complex exponentials for RoPE.

    Parameters
    ----------
    dim : int
        Dimension of each attention head (d_model // n_heads).
        Must be even.
    max_seq_len : int
        Maximum sequence length to support.
    theta : float
        Base frequency for the sinusoidal functions.

    Returns
    -------
    freqs_cis : torch.Tensor of shape (max_seq_len, dim // 2)
        Complex exponentials e^{i * position * freq} for each position
        and each frequency band.
    """
    # Frequency bands: theta^{-2k/dim} for k = 0, 1, ..., dim/2 - 1
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2).float() / dim))
    # Positions: 0, 1, ..., max_seq_len - 1
    positions = torch.arange(max_seq_len).float()
    # Outer product: (max_seq_len, dim // 2)
    angles = torch.outer(positions, freqs)
    # Complex exponentials
    freqs_cis = torch.polar(torch.ones_like(angles), angles)
    return freqs_cis


def apply_rope(x: torch.Tensor, freqs_cis: torch.Tensor) -> torch.Tensor:
    """
    Apply rotary positional encoding to query or key tensors.

    Parameters
    ----------
    x : torch.Tensor of shape (batch, seq_len, n_heads, head_dim)
        The query or key tensor.
    freqs_cis : torch.Tensor of shape (seq_len, head_dim // 2)
        Precomputed complex exponentials from precompute_rope_frequencies.

    Returns
    -------
    torch.Tensor of same shape as x, with RoPE applied.
    """
    # Reshape x into pairs of consecutive elements and view as complex numbers
    batch, seq_len, n_heads, head_dim = x.shape
    x_complex = torch.view_as_complex(
        x.float().reshape(batch, seq_len, n_heads, head_dim // 2, 2)
    )
    # Reshape freqs_cis for broadcasting: (1, seq_len, 1, head_dim // 2)
    freqs_cis = freqs_cis[:seq_len].unsqueeze(0).unsqueeze(2)
    # Multiply (rotate) and convert back to real
    x_rotated = torch.view_as_real(x_complex * freqs_cis).reshape(
        batch, seq_len, n_heads, head_dim
    )
    return x_rotated.type_as(x)


# =========================================================================
# TODO: Implement the following modules
# =========================================================================

class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization.

    Simpler than LayerNorm: normalizes by RMS (no mean centering).

        RMSNorm(x) = x / sqrt(mean(x^2) + eps) * gamma

    where gamma is a learned scale parameter of shape (dim,) initialized to ones.

    Parameters
    ----------
    dim : int
        Feature dimension to normalize over (last dimension of input).
    eps : float
        Small constant for numerical stability (default: 1e-6).
    """

    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        # TODO: Create a learnable scale parameter (gamma) of shape (dim,),
        #       initialized to ones. Store eps.
        #       Hint: use nn.Parameter and torch.ones.
        raise NotImplementedError

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        x : torch.Tensor of shape (..., dim)

        Returns
        -------
        Normalized tensor of same shape.
        """
        # TODO: Compute RMS norm:
        #   1. Compute mean of x^2 along the last dimension (keep dims).
        #   2. Normalize: x * rsqrt(mean_x2 + eps).
        #   3. Multiply by gamma.
        #       Hint: torch.rsqrt computes 1/sqrt(x).
        raise NotImplementedError


class SwiGLU(nn.Module):
    """
    SwiGLU Feed-Forward Network.

    Computes: (Swish(x @ W_gate) * (x @ W_up)) @ W_down

    where Swish(x) = x * sigmoid(x) (also called SiLU).

    Uses three linear projections:
        W_gate: (d_model, d_ff)  -- for the gating signal
        W_up:   (d_model, d_ff)  -- for the value signal
        W_down: (d_ff, d_model)  -- projects back to d_model

    Parameters
    ----------
    d_model : int
        Input and output dimension.
    d_ff : int
        Hidden dimension (typically 8/3 * d_model, rounded).
    """

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        # TODO: Create three nn.Linear layers (without bias):
        #   self.w_gate: d_model -> d_ff
        #   self.w_up:   d_model -> d_ff
        #   self.w_down: d_ff -> d_model
        raise NotImplementedError

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        x : torch.Tensor of shape (batch, seq_len, d_model)

        Returns
        -------
        torch.Tensor of shape (batch, seq_len, d_model)
        """
        # TODO: Compute SwiGLU:
        #   1. gate = F.silu(self.w_gate(x))
        #   2. up = self.w_up(x)
        #   3. return self.w_down(gate * up)
        raise NotImplementedError


class TransformerBlock(nn.Module):
    """
    A single transformer block with pre-norm residual connections.

    Structure:
        x = x + Attention(RMSNorm(x))
        x = x + FFN(RMSNorm(x))

    The attention uses multi-head causal self-attention with RoPE.

    Parameters
    ----------
    d_model : int
        Model dimension.
    n_heads : int
        Number of attention heads. d_model must be divisible by n_heads.
    d_ff : int
        Feed-forward hidden dimension.
    """

    def __init__(self, d_model: int, n_heads: int, d_ff: int):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        # TODO: Create the following layers:
        #   self.attn_norm: RMSNorm(d_model)
        #   self.ffn_norm:  RMSNorm(d_model)
        #
        #   For attention:
        #   self.wq: nn.Linear(d_model, d_model, bias=False)  -- query projection
        #   self.wk: nn.Linear(d_model, d_model, bias=False)  -- key projection
        #   self.wv: nn.Linear(d_model, d_model, bias=False)  -- value projection
        #   self.wo: nn.Linear(d_model, d_model, bias=False)  -- output projection
        #
        #   For FFN:
        #   self.ffn: SwiGLU(d_model, d_ff)
        raise NotImplementedError

    def forward(self, x: torch.Tensor, freqs_cis: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        x : torch.Tensor of shape (batch, seq_len, d_model)
        freqs_cis : torch.Tensor of shape (seq_len, head_dim // 2)
            Precomputed RoPE frequencies.

        Returns
        -------
        torch.Tensor of shape (batch, seq_len, d_model)
        """
        # TODO: Implement the forward pass:
        #
        # 1. Attention sublayer (with residual):
        #    a. Apply attn_norm to x.
        #    b. Project to q, k, v using self.wq, self.wk, self.wv.
        #    c. Reshape q, k, v from (batch, seq_len, d_model)
        #       to (batch, seq_len, n_heads, head_dim).
        #    d. Apply RoPE to q and k: q = apply_rope(q, freqs_cis),
        #       k = apply_rope(k, freqs_cis).
        #    e. Transpose to (batch, n_heads, seq_len, head_dim) for attention.
        #    f. Compute attention: F.scaled_dot_product_attention(q, k, v, is_causal=True).
        #    g. Transpose back and reshape to (batch, seq_len, d_model).
        #    h. Project with self.wo.
        #    i. Add residual: x = x + attn_output.
        #
        # 2. FFN sublayer (with residual):
        #    a. Apply ffn_norm to x.
        #    b. Pass through self.ffn.
        #    c. Add residual: x = x + ffn_output.
        #
        # Return x.
        raise NotImplementedError


class TransformerLM(nn.Module):
    """
    Decoder-only Transformer Language Model.

    Structure:
        Token Embedding -> N x TransformerBlock -> RMSNorm -> Linear Head

    The embedding and output head share weights (weight tying).

    Parameters
    ----------
    vocab_size : int
        Size of the token vocabulary.
    d_model : int
        Model dimension.
    n_layers : int
        Number of transformer blocks.
    n_heads : int
        Number of attention heads.
    d_ff : int
        Feed-forward hidden dimension.
    max_seq_len : int
        Maximum sequence length (for RoPE precomputation).
    """

    def __init__(
        self,
        vocab_size: int = 32256,
        d_model: int = 1024,
        n_layers: int = 24,
        n_heads: int = 16,
        d_ff: int = 2730,
        max_seq_len: int = 512,
    ):
        super().__init__()
        self.d_model = d_model
        self.max_seq_len = max_seq_len

        # TODO: Create the following layers:
        #   self.embedding: nn.Embedding(vocab_size, d_model)
        #   self.blocks: nn.ModuleList of n_layers TransformerBlock instances
        #   self.norm: RMSNorm(d_model)  -- final normalization
        #   self.head: nn.Linear(d_model, vocab_size, bias=False)  -- output projection
        #
        #   Weight tying: self.head.weight = self.embedding.weight
        #
        #   Precompute RoPE frequencies and register as a buffer (not a parameter):
        #   freqs_cis = precompute_rope_frequencies(d_model // n_heads, max_seq_len)
        #   self.register_buffer('freqs_cis', freqs_cis)
        raise NotImplementedError

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        token_ids : torch.LongTensor of shape (batch, seq_len)
            Input token IDs.

        Returns
        -------
        logits : torch.Tensor of shape (batch, seq_len, vocab_size)
            Unnormalized log-probabilities for each position.
        """
        # TODO: Implement the forward pass:
        #   1. Embed tokens: x = self.embedding(token_ids)
        #   2. Pass through each transformer block, providing self.freqs_cis.
        #   3. Apply final RMSNorm.
        #   4. Project to vocabulary: logits = self.head(x).
        #   Return logits.
        raise NotImplementedError

    def count_parameters(self) -> int:
        """Return total number of trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# =========================================================================
# TODO: Implement generation
# =========================================================================

@torch.no_grad()
def generate(
    model: TransformerLM,
    prompt_ids: list[int],
    max_new_tokens: int = 200,
    temperature: float = 1.0,
    top_p: float = 0.9,
    device: str = 'cuda',
) -> list[int]:
    """
    Autoregressive text generation with temperature and top-p sampling.

    Parameters
    ----------
    model : TransformerLM
        The language model (in eval mode).
    prompt_ids : list[int]
        Token IDs for the prompt (starting context).
    max_new_tokens : int
        Maximum number of new tokens to generate.
    temperature : float
        Sampling temperature. Higher = more random, lower = more deterministic.
        Use 1.0 for standard sampling, <1.0 for more focused text.
    top_p : float
        Nucleus sampling threshold. Keep the smallest set of tokens whose
        cumulative probability exceeds top_p. Use 1.0 to disable.
    device : str
        Device to run generation on.

    Returns
    -------
    list[int]
        The full sequence of token IDs (prompt + generated tokens).
    """
    # TODO: Implement autoregressive generation:
    #   1. Convert prompt_ids to a tensor on the correct device.
    #   2. For each new token (up to max_new_tokens):
    #      a. If the sequence is longer than max_seq_len, truncate from the left.
    #      b. Forward pass through the model to get logits.
    #      c. Take logits at the last position: logits[:, -1, :].
    #      d. Divide by temperature.
    #      e. Apply top-p filtering:
    #         - Sort logits descending.
    #         - Compute cumulative softmax probabilities.
    #         - Zero out (set to -inf) all tokens after cumulative prob > top_p.
    #      f. Sample from softmax of the filtered logits.
    #      g. Append the sampled token to the sequence.
    #      h. Stop early if you generate an end-of-sequence token.
    #   3. Return the full sequence as a list of ints.
    raise NotImplementedError


# =========================================================================
# Sanity checks
# =========================================================================

if __name__ == "__main__":
    print("Running model sanity checks...")

    # Test with a small model for speed
    small_model = TransformerLM(
        vocab_size=1000,
        d_model=128,
        n_layers=2,
        n_heads=4,
        d_ff=342,  # 8/3 * 128, rounded
        max_seq_len=64,
    )
    print(f"Small model parameters: {small_model.count_parameters():,}")

    # Test forward pass
    dummy_input = torch.randint(0, 1000, (2, 32))  # batch=2, seq_len=32
    logits = small_model(dummy_input)
    assert logits.shape == (2, 32, 1000), f"Expected (2, 32, 1000), got {logits.shape}"
    print(f"Forward pass OK: input {dummy_input.shape} -> output {logits.shape}")

    # Test weight tying
    assert small_model.head.weight is small_model.embedding.weight, \
        "Weight tying failed: head and embedding should share the same weight tensor"
    print("Weight tying OK")

    # Test RMSNorm
    norm = RMSNorm(128)
    x = torch.randn(2, 32, 128)
    y = norm(x)
    assert y.shape == x.shape, f"RMSNorm shape mismatch: {y.shape} vs {x.shape}"
    print("RMSNorm OK")

    # Test SwiGLU
    ffn = SwiGLU(128, 342)
    x = torch.randn(2, 32, 128)
    y = ffn(x)
    assert y.shape == x.shape, f"SwiGLU shape mismatch: {y.shape} vs {x.shape}"
    print("SwiGLU OK")

    # Verify full-size parameter count (approx)
    full_model = TransformerLM(
        vocab_size=32256,
        d_model=1024,
        n_layers=24,
        n_heads=16,
        d_ff=2730,
        max_seq_len=512,
    )
    n_params = full_model.count_parameters()
    print(f"\nFull model parameters: {n_params:,}")
    print(f"  (target: ~350M, got: {n_params / 1e6:.1f}M)")

    print("\nAll sanity checks passed!")
