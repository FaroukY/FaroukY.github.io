"""
ResNet for CIFAR-100
=====================
Implement ResNet following He et al. (2015) and train on CIFAR-100.

Reference: "Deep Residual Learning for Image Recognition"
           https://arxiv.org/abs/1512.03385

SLURM submission (on Delta):
    sbatch train_resnet.sh
"""

import json
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(42)


# =========================================================================
# TODO: Implement BasicBlock and ResNet
# =========================================================================

class BasicBlock(nn.Module):
    """
    A single residual block: two conv layers with a skip connection.

    The block computes F(x) + shortcut(x), where F is two convolutions
    and shortcut is either identity or a projection when dimensions change.

    Parameters
    ----------
    in_channels : int
        Number of input channels.
    out_channels : int
        Number of output channels.
    stride : int
        Stride for the first conv (use 2 to halve spatial dimensions).
    """

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        # TODO: Two 3x3 conv layers (each followed by BatchNorm).
        #       First conv uses the given stride; second uses stride=1.
        #       Use bias=False since BatchNorm handles the bias.
        #
        #       Define a shortcut path:
        #         - When dimensions match: identity (empty Sequential)
        #         - When they don't: a 1x1 conv to match shape
        raise NotImplementedError

    def forward(self, x):
        # TODO: Compute F(x) through the two conv layers,
        #       add the shortcut, then apply ReLU.
        #       Remember: ReLU goes AFTER the addition, not before.
        raise NotImplementedError


class ResNet(nn.Module):
    """
    ResNet for CIFAR-100.

    The network has an initial conv layer, then three stages of residual
    blocks with increasing channel counts and decreasing spatial size,
    followed by global average pooling and a linear classifier.

    Parameters
    ----------
    n : int
        Number of residual blocks per stage. n=9 gives ResNet-56.
    num_classes : int
        Number of output classes.
    """

    def __init__(self, n=9, num_classes=100):
        super().__init__()
        # TODO: Initial 3x3 conv (3 input channels -> 16) + BatchNorm.
        #       Three stages of residual blocks (use _make_stage).
        #       Channels per stage: 16, 32, 64.
        #       Stage 1 keeps spatial size; stages 2 and 3 halve it (stride=2).
        #       Final linear layer from 64 -> num_classes.
        raise NotImplementedError

        # Weight initialization (uncomment after defining your layers)
        # for m in self.modules():
        #     if isinstance(m, nn.Conv2d):
        #         nn.init.kaiming_normal_(m.weight, mode='fan_out',
        #                                 nonlinearity='relu')
        #     elif isinstance(m, nn.BatchNorm2d):
        #         nn.init.constant_(m.weight, 1)
        #         nn.init.constant_(m.bias, 0)

    def _make_stage(self, in_channels, out_channels, n_blocks, stride):
        """
        Build a sequence of n residual blocks.

        The first block may change spatial size (if stride=2) and channel
        count. All subsequent blocks keep the same dimensions.

        Returns an nn.Sequential of BasicBlocks.
        """
        # TODO
        raise NotImplementedError

    def forward(self, x):
        # TODO: Initial conv+bn+relu, then the three stages,
        #       then global average pooling (to 1x1), flatten,
        #       and the final linear layer.
        raise NotImplementedError


# =========================================================================
# Data Loading (PROVIDED)
# =========================================================================

CIFAR100_MEAN = (0.5071, 0.4867, 0.4408)
CIFAR100_STD = (0.2675, 0.2565, 0.2761)


def get_data_loaders(batch_size=128, data_dir='./data', num_workers=16):
    """
    CIFAR-100 data loaders with augmentation.
    Download the dataset on the login node FIRST:
        module load pytorch-conda/2.8
        python -c "from torchvision import datasets; datasets.CIFAR100('./data', download=True)"
    """
    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(CIFAR100_MEAN, CIFAR100_STD),
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(CIFAR100_MEAN, CIFAR100_STD),
    ])
    train_dataset = datasets.CIFAR100(
        data_dir, train=True, download=False, transform=train_transform
    )
    test_dataset = datasets.CIFAR100(
        data_dir, train=False, download=False, transform=test_transform
    )
    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True, persistent_workers=True
    )
    test_loader = DataLoader(
        test_dataset, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True, persistent_workers=True
    )
    return train_loader, test_loader


# =========================================================================
# TODO: Implement training and evaluation
# =========================================================================

def train_one_epoch(model, loader, optimizer, device):
    """
    Train for one epoch.

    Set model to train mode. For each batch: move data to device,
    do a forward pass, compute cross-entropy loss, backprop, and
    update weights. Track running loss and number of correct predictions.

    Returns (avg_loss, accuracy) where accuracy is a fraction (e.g. 0.68).
    """
    # TODO
    raise NotImplementedError


def evaluate(model, loader, device):
    """
    Evaluate on a dataset.

    Same idea as training but: use model.eval(), wrap in torch.no_grad(),
    and skip the optimizer steps.

    Returns (avg_loss, accuracy) where accuracy is a fraction.
    """
    # TODO
    raise NotImplementedError


# =========================================================================
# Main
# =========================================================================

if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    if device.type == 'cuda':
        print(f"GPU: {torch.cuda.get_device_name(0)}")

    model = ResNet(n=9, num_classes=100).to(device)
    num_params = sum(p.numel() for p in model.parameters())
    print(f"Parameters: {num_params:,}")

    train_loader, test_loader = get_data_loaders()
    print(f"Training samples: {len(train_loader.dataset):,}")
    print(f"Test samples:     {len(test_loader.dataset):,}")
    print()

    NUM_EPOCHS = 200

    # TODO: Set up an optimizer (e.g. SGD with momentum) and a learning
    #       rate scheduler (e.g. CosineAnnealingLR). See problem statement
    #       for recommended hyperparameters.

    training_log = []
    best_acc = 0.0
    total_start = time.time()

    for epoch in range(NUM_EPOCHS):
        epoch_start = time.time()

        train_loss, train_acc = train_one_epoch(model, train_loader,
                                                 optimizer, device)
        test_loss, test_acc = evaluate(model, test_loader, device)
        scheduler.step()

        epoch_time = time.time() - epoch_start
        lr = optimizer.param_groups[0]['lr']

        training_log.append({
            'epoch': epoch,
            'train_loss': train_loss,
            'train_acc': train_acc,
            'test_loss': test_loss,
            'test_acc': test_acc,
            'lr': lr,
        })

        if test_acc > best_acc:
            best_acc = test_acc
            torch.save(model, 'resnet_model.pt')

        print(f"Epoch {epoch+1:3d}/{NUM_EPOCHS} | "
              f"Train Loss: {train_loss:.3f} Acc: {train_acc*100:.1f}% | "
              f"Test Loss: {test_loss:.3f} Acc: {test_acc*100:.1f}% | "
              f"LR: {lr:.2e} | Time: {epoch_time:.1f}s")

    total_time = time.time() - total_start
    print(f"\nTotal training time: {total_time / 60:.1f} minutes")
    print(f"Best test accuracy: {best_acc*100:.1f}%")

    torch.save(model, 'resnet_model.pt')
    print("Saved model to resnet_model.pt")

    with open('training_log.json', 'w') as f:
        json.dump(training_log, f, indent=2)
    print("Saved training log to training_log.json")
