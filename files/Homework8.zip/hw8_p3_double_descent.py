"""
Double Descent Experiment
==========================
Random ReLU features + least squares on MNIST.
No gradient descent needed.

CS 498: Homework 8, Problem 3 (Part B)

Usage:
    python hw8_p3_double_descent.py
"""

import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from torchvision import datasets

np.random.seed(42)


# =========================================================================
# Data loading (PROVIDED)
# =========================================================================

def get_data(n_train=4000):
    """
    Load MNIST, subsample n_train training images, one-hot encode labels.
    Returns numpy arrays: X_train, y_train_onehot, y_train_int, X_test, y_test_int
    """
    train_set = datasets.MNIST('./data', train=True, download=False)
    test_set = datasets.MNIST('./data', train=False, download=False)

    X_train = train_set.data.numpy().reshape(-1, 784).astype(np.float64) / 255.0
    y_train = train_set.targets.numpy()
    X_test = test_set.data.numpy().reshape(-1, 784).astype(np.float64) / 255.0
    y_test = test_set.targets.numpy()

    # Subsample training set
    indices = np.random.choice(len(X_train), n_train, replace=False)
    X_train = X_train[indices]
    y_train = y_train[indices]

    # One-hot encode training labels
    y_train_oh = np.zeros((n_train, 10), dtype=np.float64)
    y_train_oh[np.arange(n_train), y_train] = 1.0

    return X_train, y_train_oh, y_train, X_test, y_test


# =========================================================================
# Experiment config (PROVIDED)
# =========================================================================

# Number of random features to sweep.
# Interpolation threshold: d = n_train = 4000.
# Dense sampling around the threshold to capture the spike.
N_FEATURES = [50, 100, 200, 400, 600, 800, 1000, 1500, 2000, 2500, 3000,
              3200, 3400, 3600, 3800, 3900, 4000, 4100, 4200, 4400, 4600,
              5000, 5500, 6000, 7000, 8000, 10000, 15000, 20000]


# =========================================================================
# TODO: Implement these two functions
# =========================================================================

def random_relu_features(X, W):
    """
    Compute random ReLU features.

    Given input X (n x 784) and random weight matrix W (d x 784),
    return the transformed features: max(0, X @ W.T), shape (n x d).
    """
    # TODO (one line)
    raise NotImplementedError


def solve_and_evaluate(X_train_feat, y_train_oh, y_train_int,
                       X_test_feat, y_test_int):
    """
    Solve the linear system with least squares and evaluate.

    1. Use np.linalg.lstsq(X_train_feat, y_train_oh) to find weights.
       This gives the minimum-norm solution (key for double descent).
    2. Compute predictions on train and test: pred_labels = argmax(X @ weights, axis=1)
    3. Compute train accuracy, test accuracy, and weight norm ||weights||.

    Returns (train_mse, train_acc, test_acc, weight_norm).
    """
    # TODO
    raise NotImplementedError


# =========================================================================
# Experiment loop and plotting (PROVIDED)
# =========================================================================

def run_experiment():
    X_train, y_train_oh, y_train_int, X_test, y_test_int = get_data()
    n_train = X_train.shape[0]
    print(f"Training samples: {n_train}")
    print(f"Test samples: {X_test.shape[0]}")

    results = []
    for d in N_FEATURES:
        print(f"\nFeatures d = {d:>6d} (d/n = {d/n_train:.2f})", flush=True)

        W = np.random.randn(d, 784) / np.sqrt(784)
        X_train_feat = random_relu_features(X_train, W)
        X_test_feat = random_relu_features(X_test, W)

        train_mse, train_acc, test_acc, w_norm = solve_and_evaluate(
            X_train_feat, y_train_oh, y_train_int, X_test_feat, y_test_int
        )

        results.append({
            'features': d,
            'ratio': round(d / n_train, 3),
            'train_mse': round(float(train_mse), 6),
            'train_acc': round(float(train_acc), 4),
            'test_acc': round(float(test_acc), 4),
            'weight_norm': round(float(w_norm), 2),
        })

        print(f"  Train Acc: {train_acc:.1%} | Test Acc: {test_acc:.1%} | "
              f"||w||: {w_norm:.1f}", flush=True)

    return results


def make_plot(results):
    features = [r['features'] for r in results]
    test_error = [1 - r['test_acc'] for r in results]
    train_error = [1 - r['train_acc'] for r in results]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    ax1.plot(features, test_error, 'o-', color='tab:blue', linewidth=2,
             markersize=5, label='Test error')
    ax1.plot(features, train_error, 's--', color='tab:orange', linewidth=1.5,
             markersize=4, alpha=0.7, label='Train error')
    ax1.axvline(x=4000, color='red', linestyle='--', alpha=0.7,
                label='Interpolation threshold (d = n)')
    ax1.set_xscale('log')
    ax1.set_xlabel('Number of random features (d)', fontsize=12)
    ax1.set_ylabel('Error (1 - accuracy)', fontsize=12)
    ax1.set_title('Double Descent: Random ReLU Features on MNIST', fontsize=13)
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)

    w_norms = [r['weight_norm'] for r in results]
    ax2.plot(features, w_norms, 'o-', color='tab:green', linewidth=2, markersize=5)
    ax2.axvline(x=4000, color='red', linestyle='--', alpha=0.7,
                label='Interpolation threshold')
    ax2.set_xscale('log')
    ax2.set_yscale('log')
    ax2.set_xlabel('Number of random features (d)', fontsize=12)
    ax2.set_ylabel('||weights||', fontsize=12)
    ax2.set_title('Weight Norm (spikes at threshold)', fontsize=13)
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig('double_descent_plot.png', dpi=150)
    print("\nSaved plot to double_descent_plot.png")
    plt.close(fig)


if __name__ == "__main__":
    results = run_experiment()

    with open('double_descent_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("\nSaved results to double_descent_results.json")

    make_plot(results)

    print(f"\n{'Features':>8} | {'d/n':>6} | {'Train Acc':>9} | "
          f"{'Test Acc':>8} | {'||w||':>8}")
    print('-' * 50)
    for r in results:
        print(f"{r['features']:>8d} | {r['ratio']:>6.3f} | "
              f"{r['train_acc']:>8.1%} | {r['test_acc']:>7.1%} | "
              f"{r['weight_norm']:>8.1f}")
