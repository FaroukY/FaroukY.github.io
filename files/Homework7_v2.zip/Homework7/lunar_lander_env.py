"""
LunarLander environment wrapper.

Requires:
    pip install gymnasium[box2d]

If you have trouble installing Box2D, try:
    pip install swig
    pip install gymnasium[box2d]
"""
import gymnasium as gym


class LunarLanderEnv:
    """Thin wrapper around Gymnasium's LunarLander-v3."""

    def __init__(self, render_mode=None):
        self.env = gym.make("LunarLander-v3", render_mode=render_mode)

    def reset(self, seed=None):
        """Reset the environment and return (observation, info)."""
        return self.env.reset(seed=seed)

    def step(self, action):
        """Take one step and return (obs, reward, terminated, truncated, info)."""
        return self.env.step(action)

    def close(self):
        """Clean up resources."""
        self.env.close()
